//
//  GoalTracker.swift
//  NewFinalApp
//
//  Created by Julie Ham on 8/12/20.
//  Copyright © 2020 Meghan Jachna. All rights reserved.
//

import UIKit

class GoalTrackerClass {
    
    var description = ""
     
}
